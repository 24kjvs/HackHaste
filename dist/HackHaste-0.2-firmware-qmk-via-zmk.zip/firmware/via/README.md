# VIA

One dictionary per variant. Layer 0 is the base sequence, layer 1 is AltGr level 3 (`U+` codepoints, combining marks for dead keys).
Map the sequence onto that board's `via.json` key order after flashing VIA-enabled QMK.

- `hackhaste-keycodes.json`
- `hackhaste-left-keycodes.json`
- `hackhaste-shiftlock-keycodes.json`
- `hackhaste-left-shiftlock-keycodes.json`
