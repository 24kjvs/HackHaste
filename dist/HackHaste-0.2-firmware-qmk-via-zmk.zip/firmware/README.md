# firmware

Logical HackHaste for programmable boards. OS packages remain outside this tree.
Source of the four maps and the AltGr pairings: `linux/xkb/haha` in the HackHaste repo.
AltGr follows the letter, the way Colemak moves US-intl level 3 with the output rather than the QWERTY position.

Each variant is its own file (not a layer of the others):

- `hackhaste` — layer 0 main, AltGr on Right Alt, Caps scancode = Left Control, physical Left Ctrl = Caps Lock
- `hackhaste-left` — geometric left-hand swap, same AltGr-follows-letter rule
- `hackhaste-shiftlock` — main letters; physical Left Ctrl latches Shift (digits and symbols included)
- `hackhaste-left-shiftlock` — left-hand letters with that Shift Lock

Shift of a base key is the US shift of that keycode. There is no separate symbol layer.
