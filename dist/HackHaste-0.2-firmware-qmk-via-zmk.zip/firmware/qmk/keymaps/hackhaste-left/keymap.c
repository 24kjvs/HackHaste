/* HackHaste Left
 * From linux/xkb/haha. Caps scancode = Left Control.
 * Physical Left Ctrl is Caps Lock (letters only).
 * AltGr is momentary on Right Alt. Level 3/4 follow the letter, as Colemak does:
 * the US-intl / Colemak AltGr symbol moves with the output, not the QWERTY position.
 * Dead keys are combining marks (firmware has no XKB dead-key state).
 * Matrix is LAYOUT_65_ansi. Transplant keycodes; do not reuse this row order
 * on the Blackberry unless that board is LAYOUT_65_ansi.
 */
#include QMK_KEYBOARD_H

enum layers { _HAHA, _ALTGR };

const uint32_t unicode_map[] PROGMEM = {
    [0] = 0x0303,
    [1] = 0x007E,
    [2] = 0x0302,
    [3] = 0x0153,
    [4] = 0x0152,
    [5] = 0x00E6,
    [6] = 0x00C6,
    [7] = 0x00E4,
    [8] = 0x00C4,
    [9] = 0x00E5,
    [10] = 0x00C5,
    [11] = 0x00F6,
    [12] = 0x00D6,
    [13] = 0x00A1,
    [14] = 0x00B9,
    [15] = 0x00BA,
    [16] = 0x00B2,
    [17] = 0x00AA,
    [18] = 0x00B3,
    [19] = 0x00A2,
    [20] = 0x00A3,
    [21] = 0x20AC,
    [22] = 0x00A5,
    [23] = 0x0127,
    [24] = 0x0126,
    [25] = 0x00F8,
    [26] = 0x00D8,
    [27] = 0x0328,
    [28] = 0x00E7,
    [29] = 0x00C7,
    [30] = 0x0142,
    [31] = 0x0141,
    [32] = 0x030A,
    [33] = 0x2013,
    [34] = 0x2014,
    [35] = 0x00F0,
    [36] = 0x00D0,
    [37] = 0x00FE,
    [38] = 0x00DE,
    [39] = 0x2018,
    [40] = 0x201C,
    [41] = 0x2019,
    [42] = 0x201D,
    [43] = 0x00AB,
    [44] = 0x2039,
    [45] = 0x00BB,
    [46] = 0x203A,
    [47] = 0x00F1,
    [48] = 0x00D1,
    [49] = 0x0301,
    [50] = 0x030B,
    [51] = 0x00DF,
    [52] = 0x0300,
    [53] = 0x030C,
    [54] = 0x00F3,
    [55] = 0x00D3,
    [56] = 0x00E9,
    [57] = 0x00C9,
    [58] = 0x00E1,
    [59] = 0x00C1,
    [60] = 0x00ED,
    [61] = 0x00CD,
    [62] = 0x00FA,
    [63] = 0x00DA,
    [64] = 0x00FC,
    [65] = 0x00DC,
    [66] = 0x00E3,
    [67] = 0x00C3,
    [68] = 0x0306,
    [69] = 0x0308,
    [70] = 0x0304,
    [71] = 0x0111,
    [72] = 0x0110,
    [73] = 0x00D7,
    [74] = 0x00F7,
    [75] = 0x00F5,
    [76] = 0x00D5,
    [77] = 0x0327,
    [78] = 0x0307,
    [79] = 0x00BF,
    [80] = 0x00A0,
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [_HAHA] = LAYOUT_65_ansi(
        KC_GRV, KC_X, KC_V, KC_Z, KC_Q, KC_W, KC_SCLN, KC_1, KC_2, KC_3, KC_4, KC_5, KC_6, KC_BSPC, KC_DEL,
        KC_TAB,  KC_P, KC_G, KC_C, KC_L, KC_K, KC_MINS, KC_7, KC_8, KC_9, KC_0, KC_LBRC, KC_RBRC, KC_BSLS, KC_HOME,
        KC_LCTL, KC_N, KC_T, KC_S, KC_R, KC_H, KC_O, KC_E, KC_A, KC_I, KC_U, KC_Y, KC_F, KC_ENT,  KC_PGUP,
        KC_LSFT,          KC_B, KC_D, KC_M, KC_J, KC_EQL, KC_QUOT, KC_COMM, KC_DOT, KC_SLSH, KC_RSFT, KC_UP,   KC_PGDN,
        KC_CAPS, KC_LGUI, KC_LALT,                            KC_SPC,                    MO(_ALTGR), KC_APP, KC_LEFT, KC_DOWN, KC_RGHT
    ),
    [_ALTGR] = LAYOUT_65_ansi(
        UP(0,1), UP(2,1), UP(3,4), UP(5,6), UP(7,8), UP(9,10), UP(11,12), UP(13,14), UP(15,16), UP(17,18), UP(19,20), UP(21,22), UP(23,24), _______, _______,
        _______, UP(25,26), UP(27,1), UP(28,29), UP(30,31), UP(32,1), UP(33,34), UP(35,36), UP(37,38), UP(39,40), UP(41,42), UP(43,44), UP(45,46), UP(1,1), _______,
        _______, UP(47,48), UP(49,50), UP(51,1), UP(52,1), UP(53,1), UP(54,55), UP(56,57), UP(58,59), UP(60,61), UP(62,63), UP(64,65), UP(66,67), _______, _______,
        _______,          UP(68,1), UP(69,1), UP(70,1), UP(71,72), UP(73,74), UP(75,76), UP(77,1), UP(78,1), UP(79,1), _______, _______, _______,
        _______, _______, _______,                            UP(80,80),                    _______, _______, _______, _______, _______
    )
};
