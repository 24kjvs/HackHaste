/* HackHaste Shift Lock
 * From linux/xkb/haha. Caps scancode = Left Control.
 * Physical Left Ctrl is Shift_Lock (latches Shift, digits included).
 * AltGr is momentary on Right Alt. Level 3/4 follow the letter, as Colemak does:
 * the US-intl / Colemak AltGr symbol moves with the output, not the QWERTY position.
 * Dead keys are combining marks (firmware has no XKB dead-key state).
 * Matrix is LAYOUT_65_ansi. Transplant keycodes; do not reuse this row order
 * on the Blackberry unless that board is LAYOUT_65_ansi.
 */
#include QMK_KEYBOARD_H

enum layers { _HAHA, _ALTGR };

enum custom_keycodes { SHLOCK = SAFE_RANGE };

static bool shift_locked = false;

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (keycode == SHLOCK) {
        if (record->event.pressed) {
            shift_locked = !shift_locked;
            if (shift_locked) {
                register_code(KC_LSFT);
            } else {
                unregister_code(KC_LSFT);
            }
        }
        return false;
    }
    return true;
}

const uint32_t unicode_map[] PROGMEM = {
    [0] = 0x0303,
    [1] = 0x007E,
    [2] = 0x00A1,
    [3] = 0x00B9,
    [4] = 0x00BA,
    [5] = 0x00B2,
    [6] = 0x00AA,
    [7] = 0x00B3,
    [8] = 0x00A2,
    [9] = 0x00A3,
    [10] = 0x20AC,
    [11] = 0x00A5,
    [12] = 0x0127,
    [13] = 0x0126,
    [14] = 0x00AB,
    [15] = 0x2039,
    [16] = 0x00BB,
    [17] = 0x203A,
    [18] = 0x0153,
    [19] = 0x0152,
    [20] = 0x0302,
    [21] = 0x00E6,
    [22] = 0x00C6,
    [23] = 0x00E4,
    [24] = 0x00C4,
    [25] = 0x00F0,
    [26] = 0x00D0,
    [27] = 0x00FE,
    [28] = 0x00DE,
    [29] = 0x2018,
    [30] = 0x201C,
    [31] = 0x2019,
    [32] = 0x201D,
    [33] = 0x2013,
    [34] = 0x2014,
    [35] = 0x030A,
    [36] = 0x0142,
    [37] = 0x0141,
    [38] = 0x00E7,
    [39] = 0x00C7,
    [40] = 0x0328,
    [41] = 0x00FC,
    [42] = 0x00DC,
    [43] = 0x00E5,
    [44] = 0x00C5,
    [45] = 0x00F6,
    [46] = 0x00D6,
    [47] = 0x00FA,
    [48] = 0x00DA,
    [49] = 0x00ED,
    [50] = 0x00CD,
    [51] = 0x00E1,
    [52] = 0x00C1,
    [53] = 0x00E9,
    [54] = 0x00C9,
    [55] = 0x00F3,
    [56] = 0x00D3,
    [57] = 0x030C,
    [58] = 0x0300,
    [59] = 0x00DF,
    [60] = 0x0301,
    [61] = 0x030B,
    [62] = 0x00F1,
    [63] = 0x00D1,
    [64] = 0x00F8,
    [65] = 0x00D8,
    [66] = 0x00F5,
    [67] = 0x00D5,
    [68] = 0x0327,
    [69] = 0x0307,
    [70] = 0x00BF,
    [71] = 0x00D7,
    [72] = 0x00F7,
    [73] = 0x0111,
    [74] = 0x0110,
    [75] = 0x0304,
    [76] = 0x0308,
    [77] = 0x0306,
    [78] = 0x00E3,
    [79] = 0x00C3,
    [80] = 0x00A0,
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [_HAHA] = LAYOUT_65_ansi(
        KC_GRV, KC_1, KC_2, KC_3, KC_4, KC_5, KC_6, KC_LBRC, KC_RBRC, KC_V, KC_X, KC_Z, KC_Q, KC_BSPC, KC_DEL,
        KC_TAB,  KC_7, KC_8, KC_9, KC_0, KC_MINS, KC_K, KC_L, KC_C, KC_G, KC_Y, KC_W, KC_SCLN, KC_BSLS, KC_HOME,
        KC_LCTL, KC_U, KC_I, KC_A, KC_E, KC_O, KC_H, KC_R, KC_S, KC_T, KC_N, KC_P, KC_QUOT, KC_ENT,  KC_PGUP,
        KC_LSFT,          KC_COMM, KC_DOT, KC_SLSH, KC_EQL, KC_J, KC_M, KC_D, KC_B, KC_F, KC_RSFT, KC_UP,   KC_PGDN,
        SHLOCK, KC_LGUI, KC_LALT,                            KC_SPC,                    MO(_ALTGR), KC_APP, KC_LEFT, KC_DOWN, KC_RGHT
    ),
    [_ALTGR] = LAYOUT_65_ansi(
        UP(0,1), UP(2,3), UP(4,5), UP(6,7), UP(8,9), UP(10,11), UP(12,13), UP(14,15), UP(16,17), UP(18,19), UP(20,1), UP(21,22), UP(23,24), _______, _______,
        _______, UP(25,26), UP(27,28), UP(29,30), UP(31,32), UP(33,34), UP(35,1), UP(36,37), UP(38,39), UP(40,1), UP(41,42), UP(43,44), UP(45,46), UP(1,1), _______,
        _______, UP(47,48), UP(49,50), UP(51,52), UP(53,54), UP(55,56), UP(57,1), UP(58,1), UP(59,1), UP(60,61), UP(62,63), UP(64,65), UP(66,67), _______, _______,
        _______,          UP(68,1), UP(69,1), UP(70,1), UP(71,72), UP(73,74), UP(75,1), UP(76,1), UP(77,1), UP(78,79), _______, _______, _______,
        _______, _______, _______,                            UP(80,80),                    _______, _______, _______, _______, _______
    )
};
