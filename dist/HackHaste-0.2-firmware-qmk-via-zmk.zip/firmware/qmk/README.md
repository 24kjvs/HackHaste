# QMK

One keymap directory per variant. All four are `LAYOUT_65_ansi`.

- `keymaps/hackhaste/`
- `keymaps/hackhaste-left/`
- `keymaps/hackhaste-shiftlock/`
- `keymaps/hackhaste-left-shiftlock/`

Right Alt is momentary AltGr (`MO(_ALTGR)`). `UP(lower, upper)` is level 3 / level 4 from `linux/xkb/haha`.
Combining marks stand in for XKB dead keys. `UNICODEMAP_ENABLE` is on; pick a Unicode input mode in `config.h`.

Shift Lock variants use `SHLOCK` on the physical Left Ctrl key. It latches `KC_LSFT`, so `1` becomes `!`.
Caps Lock scancode stays Left Control.

Board matrices differ. Transplant keycodes; do not reuse this row order on the Blackberry unless that board is `LAYOUT_65_ansi`.
