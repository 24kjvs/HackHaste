# ZMK

One keymap per variant under `boards/shields/hackhaste/`.

- `hackhaste.keymap`
- `hackhaste-left.keymap`
- `hackhaste-shiftlock.keymap`
- `hackhaste-left-shiftlock.keymap`

Layer `haha` is the base. Layer `altgr` is `&mo 1` on Right Alt. `&uni` is level 3 and is backed by the `zmk,behavior-unicode` node in each file. Shift+AltGr level 4 is the uppercase pairing in `linux/xkb/haha`.

Shift Lock variants toggle layer `shiftlock` from the physical Left Ctrl key (`&tog 2`), which is the shifted keycode of every base key. Caps position is `&kp LCTRL`.

Rebind if the shield keymap node is not ANSI order.
